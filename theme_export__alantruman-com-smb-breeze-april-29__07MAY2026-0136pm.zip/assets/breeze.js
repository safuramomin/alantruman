// ----------------- START PURCHASE SCRIPT ------------------------------------

// `breeze-purchase` event listener
window.addEventListener("breeze-purchase", (event) => {
  const eventData = event.detail;
  breezePurchase(eventData);
});

// This function will be invoked by breeze after purchase
function breezePurchase(payload) {
  try {
    merchantPurchaseCustomCode(payload.data);
  } catch (e) {
    console.log("Error in triggering merchants purchase script : ", e);
  }
}

// merchant script for `purchase` will be pasted here
function merchantPurchaseCustomCode(params) {
    console.log("Start of merchantPurchaseCustomeCode", JSON.stringify(params));

  // START OF MERCHANT CENTER CODE
    gtag("event", "purchase", {
    send_to: ["AW-948288328/w4_CCOmn25sZEMj2lsQD"],
    transaction_id: params.shopOrderId,
    value: params.totalPrice,
    currency: params.currency,
    shipping: params.shippingCharge,
    items: convertToMerchantParams(params.items),
    ignore_referrer: "true"
  })

 function convertToMerchantParams(items){
   return items.map((item)=>{
     return{
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        variant: item.variant,
        coupon: item.coupon
     }
   });
   }
  // END OF MERCHANT CENTER CODE
}

// ----------------- END PURCHASE SCRIPT --------------------------------------




